/**
 * This package contains the essential classes of CF4J.
 */
package cf4j;