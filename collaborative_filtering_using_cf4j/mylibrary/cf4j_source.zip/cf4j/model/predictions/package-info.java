/**
 * This package includes a rating prediction computers for Collaborative Filtering models.
 */
package cf4j.model.predictions;