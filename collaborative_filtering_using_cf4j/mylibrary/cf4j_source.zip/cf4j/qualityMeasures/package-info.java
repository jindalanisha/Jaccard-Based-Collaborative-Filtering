/**
 * This package contains the implementation of different quality measures.
 */
package cf4j.qualityMeasures;