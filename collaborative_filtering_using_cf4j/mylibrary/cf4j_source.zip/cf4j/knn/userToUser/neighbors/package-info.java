/**
 * This package contains the implementation of the user-to-user K Nearest Neighbors method.
 */
package cf4j.knn.userToUser.neighbors;