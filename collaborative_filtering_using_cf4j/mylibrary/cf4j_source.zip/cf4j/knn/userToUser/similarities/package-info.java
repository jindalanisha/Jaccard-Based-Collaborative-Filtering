/**
 * This package contains different implementations of user-to-user similarity measures used 
 * in the knn Collaborative Filtering algorithm.
 */
package cf4j.knn.userToUser.similarities;