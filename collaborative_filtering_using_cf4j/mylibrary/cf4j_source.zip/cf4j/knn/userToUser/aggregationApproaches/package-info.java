/**
 * This package contains the implementation of different user-to-user aggregation approaches 
 * used to calculate the user predictions in the Collaborative Filtering algorithm. 
 */
package cf4j.knn.userToUser.aggregationApproaches;