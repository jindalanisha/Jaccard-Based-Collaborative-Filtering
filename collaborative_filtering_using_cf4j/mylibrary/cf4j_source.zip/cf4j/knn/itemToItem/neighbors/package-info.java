/**
 * This package contains the implementation of the item-to-item K Nearest Neighbors method.
 */
package cf4j.knn.itemToItem.neighbors;