/**
 * This package contains different implementations of item-to-item similarity measures used 
 * in the Collaborative Filtering algorithm.
 */
package cf4j.knn.itemToItem.similarities;