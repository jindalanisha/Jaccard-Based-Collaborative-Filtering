/**
 * This package contains the implementation of different item-to-item aggregation approaches 
 * used to calculate the user predictions in the Collaborative Filtering algorithm. 
 */
package cf4j.knn.itemToItem.aggreagationApproaches;